"""Tests for PromptHound rules and scanner."""
from __future__ import annotations

from pathlib import Path

import pytest

from prompthound.finding import Severity
from prompthound.rules import ScanContext
from prompthound.rules.secrets import HardcodedSecretsRule
from prompthound.rules.prompt_injection import PromptInjectionRule
from prompthound.rules.unsafe_output import UnsafeOutputExecutionRule
from prompthound.rules.data_leakage import DataLeakageRule
from prompthound.rules.deserialization import InsecureDeserializationRule
from prompthound.rules.tool_sinks import ModelOutputToSinkRule
from prompthound.scanner import Scanner

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"


def ctx(src: str) -> ScanContext:
    return ScanContext.build("test.py", src)


# ---- individual rules -----------------------------------------------------

def test_detects_hardcoded_openai_key():
    src = 'KEY = "sk-proj-1a2b3c4d5e6f7g8h9i0jABCDEFGHIJKLMNOP"\n'
    findings = HardcodedSecretsRule().scan(ctx(src))
    assert findings and findings[0].rule_id == "PH101"


def test_ignores_env_var_key():
    src = 'api_key = os.environ["OPENAI_API_KEY"]\n'
    assert HardcodedSecretsRule().scan(ctx(src)) == []


def test_ignores_placeholder_key():
    src = 'api_key = "your-api-key-here-placeholder"\n'
    assert HardcodedSecretsRule().scan(ctx(src)) == []


def test_detects_prompt_injection_fstring():
    src = 'prompt = f"Answer: {user_input}"\n'
    findings = PromptInjectionRule().scan(ctx(src))
    assert findings and findings[0].rule_id == "PH201"


def test_static_prompt_is_clean():
    src = 'prompt = "You are a helpful assistant."\n'
    assert PromptInjectionRule().scan(ctx(src)) == []


def test_detects_eval_on_model_output():
    src = "x = eval(completion)\n"
    findings = UnsafeOutputExecutionRule().scan(ctx(src))
    assert findings and findings[0].severity == Severity.CRITICAL


def test_flags_bare_eval_lower_severity():
    src = "x = eval(something_else)\n"
    findings = UnsafeOutputExecutionRule().scan(ctx(src))
    assert findings and findings[0].severity == Severity.HIGH


def test_detects_logging_completion():
    src = "print('out', completion)\n"
    findings = DataLeakageRule().scan(ctx(src))
    assert findings and findings[0].rule_id == "PH401"


def test_detects_pickle_loads():
    src = "obj = pickle.loads(data)\n"
    findings = InsecureDeserializationRule().scan(ctx(src))
    assert findings and findings[0].rule_id == "PH501"


def test_yaml_safe_load_is_clean():
    src = "obj = yaml.safe_load(data)\n"
    assert InsecureDeserializationRule().scan(ctx(src)) == []


def test_detects_ssrf_from_model_output():
    src = "requests.get(llm_output)\n"
    findings = ModelOutputToSinkRule().scan(ctx(src))
    assert findings and findings[0].rule_id == "PH601"


# ---- end-to-end -----------------------------------------------------------

def test_vulnerable_example_has_findings():
    result = Scanner().scan_path(str(EXAMPLES / "vulnerable_app.py"))
    ids = {f.rule_id for f in result.findings}
    assert {"PH101", "PH201", "PH301", "PH401", "PH501", "PH601"} <= ids


def test_safe_example_is_clean():
    result = Scanner().scan_path(str(EXAMPLES / "safe_app.py"))
    assert result.findings == [], [f.message for f in result.findings]


def test_scanner_respects_min_severity():
    result = Scanner(min_severity=Severity.CRITICAL).scan_path(
        str(EXAMPLES / "vulnerable_app.py")
    )
    assert all(f.severity == Severity.CRITICAL for f in result.findings)
