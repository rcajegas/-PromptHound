"""Intentionally insecure sample LLM app.

This file exists ONLY to demonstrate what PromptHound detects. Do not use any
of these patterns in real code. Run:  prompthound examples/vulnerable_app.py
"""
import os
import pickle
import subprocess

import requests
from openai import OpenAI

# PH101: hardcoded credential
OPENAI_API_KEY = "sk-proj-1a2b3c4d5e6f7g8h9i0jABCDEFGHIJKLMNOP"

client = OpenAI(api_key=OPENAI_API_KEY)


def answer(user_question: str) -> str:
    # PH201: untrusted input welded straight into the prompt
    prompt = f"You are a helpful assistant. Answer this: {user_question}"

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
    )
    completion = response.choices[0].message.content

    # PH401: logging raw prompt and completion (PII / secret leakage)
    print("PROMPT:", prompt, "COMPLETION:", completion)

    # PH301: executing model output
    result = eval(completion)  # noqa

    # PH601: model output used as a URL (SSRF)
    requests.get(completion)

    # PH301: model output piped to a shell
    subprocess.run(completion, shell=True)

    return result


def load_cache(blob):
    # PH501: insecure deserialization
    return pickle.loads(blob)
