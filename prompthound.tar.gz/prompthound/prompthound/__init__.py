"""PromptHound — a static analyzer that sniffs out AI/LLM security flaws.

PromptHound scans source code for security issues specific to applications
that build on large language models: hardcoded provider credentials,
prompt-injection surfaces, unsafe execution of model output, data leakage,
insecure deserialization, and model output reaching sensitive sinks.
"""
from __future__ import annotations

__version__ = "0.1.0"

from .finding import Finding, Severity
from .scanner import Scanner, ScanResult
from .rules import all_rules

__all__ = [
    "__version__",
    "Finding",
    "Severity",
    "Scanner",
    "ScanResult",
    "all_rules",
]
