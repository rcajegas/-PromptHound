"""Core data structures for scan findings."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional


class Severity(str, Enum):
    """Ordered severity levels. Higher index = more severe."""

    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    @property
    def rank(self) -> int:
        order = [
            Severity.INFO,
            Severity.LOW,
            Severity.MEDIUM,
            Severity.HIGH,
            Severity.CRITICAL,
        ]
        return order.index(self)

    def __ge__(self, other: "Severity") -> bool:  # type: ignore[override]
        if isinstance(other, Severity):
            return self.rank >= other.rank
        return NotImplemented


@dataclass
class Finding:
    """A single security issue discovered by a rule."""

    rule_id: str
    rule_name: str
    severity: Severity
    message: str
    file: str
    line: int
    column: int = 0
    snippet: str = ""
    remediation: str = ""
    cwe: Optional[str] = None
    references: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["severity"] = self.severity.value
        return d

    @property
    def location(self) -> str:
        return f"{self.file}:{self.line}:{self.column}"
