"""File discovery and scan orchestration."""
from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from .finding import Finding, Severity
from .rules import Rule, ScanContext, all_rules

# Extensions we attempt to read. Python gets full AST rules; others get the
# line/regex rules (e.g. secrets) only.
DEFAULT_INCLUDE = ("*.py", "*.pyi", "*.ipynb_text", "*.env", "*.cfg", "*.ini",
                   "*.yaml", "*.yml", "*.toml", "*.txt")

DEFAULT_EXCLUDE_DIRS = {
    ".git", ".hg", ".svn", "__pycache__", ".venv", "venv", "env",
    "node_modules", ".mypy_cache", ".pytest_cache", "build", "dist",
    ".tox", "site-packages", ".ruff_cache",
}

MAX_FILE_BYTES = 2_000_000  # skip very large files


@dataclass
class ScanStats:
    files_scanned: int = 0
    files_skipped: int = 0
    rules_run: int = 0


@dataclass
class ScanResult:
    findings: list[Finding] = field(default_factory=list)
    stats: ScanStats = field(default_factory=ScanStats)

    def sorted_findings(self) -> list[Finding]:
        return sorted(
            self.findings,
            key=lambda f: (-f.severity.rank, f.file, f.line),
        )

    def count_by_severity(self) -> dict[str, int]:
        counts = {s.value: 0 for s in Severity}
        for f in self.findings:
            counts[f.severity.value] += 1
        return counts

    def max_severity(self) -> Optional[Severity]:
        if not self.findings:
            return None
        return max((f.severity for f in self.findings), key=lambda s: s.rank)


class Scanner:
    def __init__(
        self,
        rules: Optional[list[Rule]] = None,
        include: Iterable[str] = DEFAULT_INCLUDE,
        exclude_dirs: Optional[set[str]] = None,
        min_severity: Severity = Severity.INFO,
    ) -> None:
        self.rules = rules if rules is not None else all_rules()
        self.include = tuple(include)
        self.exclude_dirs = exclude_dirs or set(DEFAULT_EXCLUDE_DIRS)
        self.min_severity = min_severity

    # ---- discovery --------------------------------------------------------

    def _matches_include(self, filename: str) -> bool:
        return any(fnmatch.fnmatch(filename, pat) for pat in self.include)

    def discover(self, root: str) -> list[str]:
        rootp = Path(root)
        if rootp.is_file():
            return [str(rootp)]
        found: list[str] = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in self.exclude_dirs]
            for fn in filenames:
                if self._matches_include(fn):
                    found.append(os.path.join(dirpath, fn))
        return sorted(found)

    # ---- scanning ---------------------------------------------------------

    def scan_path(self, root: str) -> ScanResult:
        result = ScanResult()
        result.stats.rules_run = len(self.rules)
        for path in self.discover(root):
            try:
                if os.path.getsize(path) > MAX_FILE_BYTES:
                    result.stats.files_skipped += 1
                    continue
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    source = fh.read()
            except OSError:
                result.stats.files_skipped += 1
                continue

            ctx = ScanContext.build(path, source)
            result.stats.files_scanned += 1
            for rule in self.rules:
                try:
                    for finding in rule.scan(ctx):
                        if finding.severity.rank >= self.min_severity.rank:
                            result.findings.append(finding)
                except Exception:  # a buggy rule must not abort the scan
                    continue
        return result
