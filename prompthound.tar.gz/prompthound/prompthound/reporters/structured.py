"""JSON, SARIF, and Markdown reporters."""
from __future__ import annotations

import json
from datetime import datetime, timezone

from ..finding import Severity
from ..scanner import ScanResult
from ..rules import rules_by_id

_SARIF_LEVEL = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}


def to_json(result: ScanResult) -> str:
    payload = {
        "tool": "prompthound",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "stats": {
            "files_scanned": result.stats.files_scanned,
            "files_skipped": result.stats.files_skipped,
            "rules_run": result.stats.rules_run,
        },
        "summary": result.count_by_severity(),
        "findings": [f.to_dict() for f in result.sorted_findings()],
    }
    return json.dumps(payload, indent=2)


def to_sarif(result: ScanResult) -> str:
    """SARIF 2.1.0 — uploadable to GitHub code scanning."""
    reg = rules_by_id()
    rule_descriptors = [
        {
            "id": rid,
            "name": rule.name,
            "shortDescription": {"text": rule.name},
            "fullDescription": {"text": rule.description},
            "helpUri": (rule.references[0] if rule.references else ""),
            "properties": {"tags": ["security", "ai", "llm"]},
        }
        for rid, rule in reg.items()
    ]
    results = []
    for f in result.sorted_findings():
        results.append({
            "ruleId": f.rule_id,
            "level": _SARIF_LEVEL[f.severity],
            "message": {"text": f.message},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": f.file},
                    "region": {"startLine": max(f.line, 1),
                               "startColumn": max(f.column, 1)},
                }
            }],
            "properties": {"severity": f.severity.value, "cwe": f.cwe},
        })
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {
                "name": "PromptHound",
                "informationUri": "https://github.com/your-org/prompthound",
                "rules": rule_descriptors,
            }},
            "results": results,
        }],
    }
    return json.dumps(sarif, indent=2)


def to_markdown(result: ScanResult) -> str:
    counts = result.count_by_severity()
    lines = ["# PromptHound report", ""]
    lines.append(
        f"Scanned **{result.stats.files_scanned}** files with "
        f"**{result.stats.rules_run}** rules.\n"
    )
    badge = " · ".join(
        f"{counts[s.value]} {s.value}"
        for s in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]
        if counts[s.value]
    ) or "no findings"
    lines.append(f"**Summary:** {badge}\n")

    findings = result.sorted_findings()
    if not findings:
        lines.append("No issues found. ✓")
        return "\n".join(lines)

    lines.append("| Severity | Rule | Location | Issue |")
    lines.append("| --- | --- | --- | --- |")
    for f in findings:
        msg = f.message.replace("|", "\\|")
        lines.append(
            f"| {f.severity.value.upper()} | `{f.rule_id}` {f.rule_name} "
            f"| `{f.location}` | {msg} |"
        )
    lines.append("")
    lines.append("## Details")
    for f in findings:
        lines.append(f"\n### {f.rule_id} — {f.rule_name} ({f.severity.value})")
        lines.append(f"- **Location:** `{f.location}`")
        if f.snippet:
            lines.append(f"- **Code:** `{f.snippet}`")
        lines.append(f"- **Issue:** {f.message}")
        if f.remediation:
            lines.append(f"- **Fix:** {f.remediation}")
        if f.cwe:
            lines.append(f"- **CWE:** {f.cwe}")
    return "\n".join(lines)
