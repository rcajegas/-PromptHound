"""Human-readable terminal reporter."""
from __future__ import annotations

import os
import sys

from ..finding import Severity
from ..scanner import ScanResult

_COLORS = {
    Severity.CRITICAL: "\033[97;41m",
    Severity.HIGH: "\033[91m",
    Severity.MEDIUM: "\033[93m",
    Severity.LOW: "\033[94m",
    Severity.INFO: "\033[90m",
}
_RESET = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"


def _use_color(stream) -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(stream, "isatty") and stream.isatty()


def render(result: ScanResult, stream=None) -> None:
    stream = stream or sys.stdout
    color = _use_color(stream)

    def c(text: str, code: str) -> str:
        return f"{code}{text}{_RESET}" if color else text

    findings = result.sorted_findings()
    if not findings:
        stream.write(c("✓ PromptHound: no issues found.\n", _BOLD))
    else:
        for f in findings:
            tag = c(f" {f.severity.value.upper()} ", _COLORS[f.severity]) if color \
                else f"[{f.severity.value.upper()}]"
            stream.write(f"{tag} {c(f.rule_id, _BOLD)} {f.rule_name}\n")
            stream.write(f"  {c(f.location, _DIM)}\n")
            stream.write(f"  {f.message}\n")
            if f.snippet:
                stream.write(f"  {c('|', _DIM)} {c(f.snippet, _DIM)}\n")
            if f.remediation:
                stream.write(f"  {c('fix:', _BOLD)} {f.remediation}\n")
            if f.cwe:
                stream.write(f"  {c(f.cwe, _DIM)}\n")
            stream.write("\n")

    counts = result.count_by_severity()
    summary_parts = []
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]:
        n = counts[sev.value]
        if n:
            summary_parts.append(c(f"{n} {sev.value}", _COLORS[sev]))
    summary = "  ".join(summary_parts) if summary_parts else "0 findings"
    stream.write(c("── summary ──\n", _BOLD))
    stream.write(
        f"{result.stats.files_scanned} files scanned, "
        f"{result.stats.rules_run} rules · {summary}\n"
    )
