"""Output reporters for scan results."""
from __future__ import annotations

from ..scanner import ScanResult
from . import terminal
from .structured import to_json, to_markdown, to_sarif


def render(result: ScanResult, fmt: str) -> str | None:
    """Render a result in the requested format.

    Returns a string for structured formats, or None for 'terminal'
    (which writes directly to stdout).
    """
    if fmt == "terminal":
        terminal.render(result)
        return None
    if fmt == "json":
        return to_json(result)
    if fmt == "sarif":
        return to_sarif(result)
    if fmt == "markdown":
        return to_markdown(result)
    raise ValueError(f"unknown format: {fmt}")


__all__ = ["render", "to_json", "to_sarif", "to_markdown", "terminal"]
