"""Rule registry. Import all rules and expose the default rule set."""
from __future__ import annotations

from .base import Rule, ScanContext
from .data_leakage import DataLeakageRule
from .deserialization import InsecureDeserializationRule
from .prompt_injection import PromptInjectionRule
from .secrets import HardcodedSecretsRule
from .tool_sinks import ModelOutputToSinkRule
from .unsafe_output import UnsafeOutputExecutionRule

# Instantiate once; rules are stateless.
DEFAULT_RULES: list[Rule] = [
    HardcodedSecretsRule(),
    PromptInjectionRule(),
    UnsafeOutputExecutionRule(),
    DataLeakageRule(),
    InsecureDeserializationRule(),
    ModelOutputToSinkRule(),
]


def all_rules() -> list[Rule]:
    return list(DEFAULT_RULES)


def rules_by_id() -> dict[str, Rule]:
    return {r.id: r for r in DEFAULT_RULES}


__all__ = [
    "Rule",
    "ScanContext",
    "DEFAULT_RULES",
    "all_rules",
    "rules_by_id",
]
