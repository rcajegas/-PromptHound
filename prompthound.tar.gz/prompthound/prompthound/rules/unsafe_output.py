"""Detect LLM output flowing into dangerous sinks (code/command execution)."""
from __future__ import annotations

import ast

from ..finding import Severity
from .base import Rule, ScanContext
from ._ast_utils import RESPONSE_NAME_HINTS, call_name, name_matches

# Sinks that execute code or shell commands.
_CODE_SINKS = {"eval", "exec"}
_SHELL_SINKS = {
    "os.system",
    "os.popen",
    "subprocess.run",
    "subprocess.call",
    "subprocess.Popen",
    "subprocess.check_output",
    "subprocess.check_call",
}


def _arg_references_llm_output(node: ast.AST) -> bool:
    """True if any Name in the expression looks like an LLM response var."""
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name) and name_matches(sub.id, RESPONSE_NAME_HINTS):
            return True
        if isinstance(sub, ast.Attribute) and name_matches(sub.attr, RESPONSE_NAME_HINTS):
            return True
    return False


class UnsafeOutputExecutionRule(Rule):
    id = "PH301"
    name = "unsafe-llm-output-execution"
    severity = Severity.CRITICAL
    description = (
        "Never pass model output to eval/exec or a shell. If you must act on "
        "model output, use a strict allow-list of operations, structured tool "
        "calls with validated arguments, and a sandbox."
    )
    cwe = "CWE-94"
    references = [
        "https://owasp.org/www-project-top-10-for-large-language-model-applications/",
    ]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        if not ctx.tree:
            return []
        findings: list[Finding] = []

        for node in ast.walk(ctx.tree):
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node)
            short = name.split(".")[-1]

            is_code_sink = short in _CODE_SINKS
            is_shell_sink = name in _SHELL_SINKS or short in {"system", "popen"}

            if not (is_code_sink or is_shell_sink):
                continue

            llm_tainted = any(
                _arg_references_llm_output(a) for a in node.args
            ) or any(_arg_references_llm_output(k.value) for k in node.keywords)

            # shell=True raises severity for subprocess sinks.
            shell_true = any(
                isinstance(k.value, ast.Constant)
                and k.value.value is True
                and k.arg == "shell"
                for k in node.keywords
            )

            if llm_tainted:
                findings.append(
                    self.make_finding(
                        ctx,
                        node.lineno,
                        f"Model output appears to flow into '{name}()' — remote "
                        "code/command execution risk.",
                        column=node.col_offset + 1,
                        severity=Severity.CRITICAL,
                    )
                )
            elif is_code_sink:
                findings.append(
                    self.make_finding(
                        ctx,
                        node.lineno,
                        f"Use of '{short}()'. If any argument can derive from model "
                        "or user input this is a code-execution sink.",
                        column=node.col_offset + 1,
                        severity=Severity.HIGH,
                    )
                )
            elif shell_true:
                findings.append(
                    self.make_finding(
                        ctx,
                        node.lineno,
                        f"'{name}(..., shell=True)' — command-injection risk if any "
                        "argument derives from model or user input.",
                        column=node.col_offset + 1,
                        severity=Severity.MEDIUM,
                    )
                )
        return findings
