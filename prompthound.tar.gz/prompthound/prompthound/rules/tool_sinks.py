"""Detect model output reaching network/file sinks (SSRF, path traversal)."""
from __future__ import annotations

import ast

from ..finding import Severity
from .base import Rule, ScanContext
from ._ast_utils import RESPONSE_NAME_HINTS, call_name, name_matches

_NET_SINKS = {
    "requests.get",
    "requests.post",
    "requests.put",
    "requests.delete",
    "requests.request",
    "httpx.get",
    "httpx.post",
    "urllib.request.urlopen",
    "aiohttp.request",
}
_FILE_SINKS = {"open", "os.remove", "os.unlink", "shutil.rmtree", "pathlib.Path"}


def _tainted_args(node: ast.Call) -> bool:
    for a in list(node.args) + [k.value for k in node.keywords]:
        for sub in ast.walk(a):
            if isinstance(sub, ast.Name) and name_matches(sub.id, RESPONSE_NAME_HINTS):
                return True
            if isinstance(sub, ast.Attribute) and name_matches(sub.attr, RESPONSE_NAME_HINTS):
                return True
    return False


class ModelOutputToSinkRule(Rule):
    id = "PH601"
    name = "model-output-to-sensitive-sink"
    severity = Severity.HIGH
    description = (
        "Model/tool output flowing into HTTP requests or filesystem calls enables "
        "SSRF and path traversal. Validate against an allow-list of hosts/paths, "
        "resolve and confine paths, and block internal address ranges."
    )
    cwe = "CWE-918"
    references = ["https://owasp.org/www-community/attacks/Server_Side_Request_Forgery"]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        if not ctx.tree:
            return []
        findings: list[Finding] = []
        for node in ast.walk(ctx.tree):
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node)
            is_net = name in _NET_SINKS
            is_file = name in _FILE_SINKS or name.split(".")[-1] == "open"
            if not (is_net or is_file):
                continue
            if not _tainted_args(node):
                continue
            kind = "network request (SSRF)" if is_net else "filesystem access (path traversal)"
            findings.append(
                self.make_finding(
                    ctx,
                    node.lineno,
                    f"Model/tool output appears to reach '{name}()' — {kind} risk.",
                    column=node.col_offset + 1,
                )
            )
        return findings
