"""Base classes for scan rules and the shared scan context."""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from typing import Optional

from ..finding import Finding, Severity


@dataclass
class ScanContext:
    """Everything a rule needs to analyze a single file."""

    path: str
    source: str
    lines: list[str] = field(default_factory=list)
    tree: Optional[ast.AST] = None
    is_python: bool = False

    @classmethod
    def build(cls, path: str, source: str) -> "ScanContext":
        lines = source.splitlines()
        is_python = path.endswith(".py")
        tree = None
        if is_python:
            try:
                tree = ast.parse(source, filename=path)
            except SyntaxError:
                # Unparseable Python still gets line/regex based rules.
                is_python = False
        return cls(
            path=path,
            source=source,
            lines=lines,
            tree=tree,
            is_python=is_python,
        )

    def snippet(self, line: int) -> str:
        idx = line - 1
        if 0 <= idx < len(self.lines):
            return self.lines[idx].strip()
        return ""


class Rule:
    """A detector for one class of AI/LLM security issue.

    Subclasses set the class attributes and implement ``scan``.
    """

    id: str = "PH000"
    name: str = "unnamed-rule"
    severity: Severity = Severity.MEDIUM
    description: str = ""
    cwe: Optional[str] = None
    references: list[str] = []

    def scan(self, ctx: ScanContext) -> list[Finding]:  # pragma: no cover
        raise NotImplementedError

    # ---- helpers shared by subclasses -------------------------------------

    def make_finding(
        self,
        ctx: ScanContext,
        line: int,
        message: str,
        *,
        column: int = 0,
        remediation: str = "",
        severity: Optional[Severity] = None,
    ) -> Finding:
        return Finding(
            rule_id=self.id,
            rule_name=self.name,
            severity=severity or self.severity,
            message=message,
            file=ctx.path,
            line=line,
            column=column,
            snippet=ctx.snippet(line),
            remediation=remediation or self.description,
            cwe=self.cwe,
            references=list(self.references),
        )
