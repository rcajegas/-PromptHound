"""Detect logging/printing of prompts and completions (data leakage)."""
from __future__ import annotations

import ast

from ..finding import Severity
from .base import Rule, ScanContext
from ._ast_utils import (
    PROMPT_NAME_HINTS,
    RESPONSE_NAME_HINTS,
    call_name,
    name_matches,
)

_LOG_CALLS = {
    "print",
    "logging.info",
    "logging.debug",
    "logging.warning",
    "logging.error",
    "logger.info",
    "logger.debug",
    "logger.warning",
    "logger.error",
    "log.info",
    "log.debug",
}

_SENSITIVE_HINTS = tuple(set(PROMPT_NAME_HINTS + RESPONSE_NAME_HINTS + (
    "messages",
    "api_key",
    "apikey",
    "conversation",
    "chat_history",
)))


def _mentions_sensitive(node: ast.AST) -> str | None:
    for sub in ast.walk(node):
        if isinstance(sub, ast.Name) and name_matches(sub.id, _SENSITIVE_HINTS):
            return sub.id
        if isinstance(sub, ast.Attribute) and name_matches(sub.attr, _SENSITIVE_HINTS):
            return sub.attr
    return None


class DataLeakageRule(Rule):
    id = "PH401"
    name = "prompt-completion-logging"
    severity = Severity.MEDIUM
    description = (
        "Avoid logging raw prompts, completions, message histories, or keys. "
        "They frequently contain PII and secrets. Redact or hash before logging, "
        "and gate verbose logging behind a debug flag."
    )
    cwe = "CWE-532"
    references = [
        "https://cwe.mitre.org/data/definitions/532.html",
    ]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        if not ctx.tree:
            return []
        findings: list[Finding] = []
        for node in ast.walk(ctx.tree):
            if not isinstance(node, ast.Call):
                continue
            if call_name(node) not in _LOG_CALLS:
                continue
            for arg in list(node.args) + [k.value for k in node.keywords]:
                hit = _mentions_sensitive(arg)
                if hit:
                    findings.append(
                        self.make_finding(
                            ctx,
                            node.lineno,
                            f"Logging statement references '{hit}', which may expose "
                            "prompt/completion data or secrets.",
                            column=node.col_offset + 1,
                        )
                    )
                    break
        return findings
