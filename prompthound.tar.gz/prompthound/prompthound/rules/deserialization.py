"""Detect insecure deserialization, esp. on model/tool output."""
from __future__ import annotations

import ast

from ..finding import Severity
from .base import Rule, ScanContext
from ._ast_utils import RESPONSE_NAME_HINTS, call_name, name_matches

# name -> (severity, note)
_SINKS = {
    "pickle.loads": (Severity.HIGH, "pickle deserialization is arbitrary-code-exec"),
    "pickle.load": (Severity.HIGH, "pickle deserialization is arbitrary-code-exec"),
    "cloudpickle.loads": (Severity.HIGH, "cloudpickle deserialization is arbitrary-code-exec"),
    "yaml.load": (Severity.HIGH, "yaml.load without SafeLoader executes arbitrary tags"),
    "torch.load": (Severity.MEDIUM, "torch.load unpickles by default; use weights_only=True"),
    "joblib.load": (Severity.MEDIUM, "joblib.load unpickles arbitrary objects"),
}


def _tainted(node: ast.Call) -> bool:
    for a in list(node.args) + [k.value for k in node.keywords]:
        for sub in ast.walk(a):
            if isinstance(sub, ast.Name) and name_matches(sub.id, RESPONSE_NAME_HINTS):
                return True
            if isinstance(sub, ast.Attribute) and name_matches(sub.attr, RESPONSE_NAME_HINTS):
                return True
    return False


class InsecureDeserializationRule(Rule):
    id = "PH501"
    name = "insecure-deserialization"
    severity = Severity.HIGH
    description = (
        "Do not deserialize untrusted data with pickle/torch.load/yaml.load. "
        "Use safe formats (JSON), yaml.safe_load, or torch.load(weights_only=True), "
        "and never unpickle data derived from model or tool output."
    )
    cwe = "CWE-502"
    references = ["https://cwe.mitre.org/data/definitions/502.html"]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        if not ctx.tree:
            return []
        findings: list[Finding] = []
        for node in ast.walk(ctx.tree):
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node)
            if name not in _SINKS:
                continue

            # yaml.load with an explicit safe loader is fine.
            if name == "yaml.load":
                loaders = " ".join(
                    (k.arg or "") + str(getattr(k.value, "attr", ""))
                    for k in node.keywords
                )
                if "SafeLoader" in ast.dump(node) or "safe" in loaders.lower():
                    continue

            base_sev, note = _SINKS[name]
            sev = Severity.CRITICAL if _tainted(node) else base_sev
            suffix = " on model/tool output" if _tainted(node) else ""
            findings.append(
                self.make_finding(
                    ctx,
                    node.lineno,
                    f"{name}(){suffix}: {note}.",
                    column=node.col_offset + 1,
                    severity=sev,
                )
            )
        return findings
