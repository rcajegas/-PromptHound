"""AST helpers shared across rules."""
from __future__ import annotations

import ast
from typing import Iterable


def dotted_name(node: ast.AST) -> str:
    """Return the dotted attribute/name path for a call target.

    e.g. ``client.chat.completions.create`` -> that exact string.
    Returns "" when the node is not a name/attribute chain.
    """
    parts: list[str] = []
    cur = node
    while isinstance(cur, ast.Attribute):
        parts.append(cur.attr)
        cur = cur.value
    if isinstance(cur, ast.Name):
        parts.append(cur.id)
    else:
        return ""
    return ".".join(reversed(parts))


def call_name(node: ast.Call) -> str:
    return dotted_name(node.func)


def string_value(node: ast.AST) -> str | None:
    """Return the literal string value of a constant, else None."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def contains_untrusted_composition(node: ast.AST) -> bool:
    """True when a node builds a string from dynamic parts.

    Matches f-strings with interpolation, ``a + b`` concatenation,
    ``"...".format(...)`` and ``"..." % (...)`` — the common ways user
    input gets welded into a prompt.
    """
    if isinstance(node, ast.JoinedStr):
        return any(isinstance(v, ast.FormattedValue) for v in node.values)
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mod)):
        return True
    if isinstance(node, ast.Call):
        fn = node.func
        if isinstance(fn, ast.Attribute) and fn.attr == "format":
            return True
    return False


def iter_string_args(node: ast.Call) -> Iterable[ast.AST]:
    """Yield positional and keyword argument value nodes of a call."""
    yield from node.args
    for kw in node.keywords:
        if kw.value is not None:
            yield kw.value


# Variable-name heuristics -------------------------------------------------

PROMPT_NAME_HINTS = (
    "prompt",
    "system_prompt",
    "sys_prompt",
    "template",
    "instruction",
    "user_message",
    "user_msg",
)

RESPONSE_NAME_HINTS = (
    "response",
    "completion",
    "llm_output",
    "model_output",
    "answer",
    "generated",
    "ai_output",
    "assistant_reply",
    "chat_response",
)


def name_matches(name: str, hints: Iterable[str]) -> bool:
    low = name.lower()
    return any(h in low for h in hints)
