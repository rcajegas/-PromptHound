"""Detect prompt-injection surface: dynamic data welded into LLM prompts."""
from __future__ import annotations

import ast

from ..finding import Severity
from .base import Rule, ScanContext
from ._ast_utils import (
    PROMPT_NAME_HINTS,
    call_name,
    contains_untrusted_composition,
    iter_string_args,
    name_matches,
    string_value,
)

# Call targets that end in one of these are treated as LLM invocations.
_LLM_CALL_SUFFIXES = (
    "chat.completions.create",
    "completions.create",
    "messages.create",
    "chatcompletion.create",
    "completion.create",
    "generate_content",
    "invoke",
    "predict",
    "complete",
)


def _looks_like_llm_call(name: str) -> bool:
    low = name.lower()
    return any(low.endswith(sfx) for sfx in _LLM_CALL_SUFFIXES)


class PromptInjectionRule(Rule):
    id = "PH201"
    name = "prompt-injection-surface"
    severity = Severity.HIGH
    description = (
        "Keep untrusted input out of the instruction portion of a prompt. "
        "Pass user data as clearly delimited content, validate/escape it, and "
        "keep system instructions in a separate, static message."
    )
    cwe = "CWE-1427"
    references = [
        "https://owasp.org/www-project-top-10-for-large-language-model-applications/",
    ]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        if not ctx.tree:
            return []
        findings: list[Finding] = []

        for node in ast.walk(ctx.tree):
            # 1. Prompt-like variables built from dynamic strings.
            if isinstance(node, ast.Assign):
                targets = [
                    t.id for t in node.targets if isinstance(t, ast.Name)
                ]
                if any(name_matches(t, PROMPT_NAME_HINTS) for t in targets):
                    if contains_untrusted_composition(node.value):
                        var = next(
                            t for t in targets
                            if name_matches(t, PROMPT_NAME_HINTS)
                        )
                        findings.append(
                            self.make_finding(
                                ctx,
                                node.lineno,
                                f"Prompt variable '{var}' is built by interpolating "
                                "dynamic data; this is a prompt-injection surface.",
                                column=node.col_offset + 1,
                            )
                        )

            # 2. Dynamic string passed directly into an LLM call argument.
            elif isinstance(node, ast.Call) and _looks_like_llm_call(call_name(node)):
                for arg in iter_string_args(node):
                    if contains_untrusted_composition(arg):
                        findings.append(
                            self.make_finding(
                                ctx,
                                getattr(arg, "lineno", node.lineno),
                                "Dynamically composed string passed to an LLM call; "
                                "untrusted input may reach the model's instructions.",
                                column=getattr(arg, "col_offset", node.col_offset) + 1,
                            )
                        )
                    # System prompt as a raw f-string is worth flagging too.
                    elif isinstance(arg, ast.JoinedStr):
                        text = "".join(
                            string_value(v) or ""
                            for v in arg.values
                            if isinstance(v, ast.Constant)
                        )
                        if "ignore" in text.lower() and "instruction" in text.lower():
                            findings.append(
                                self.make_finding(
                                    ctx,
                                    arg.lineno,
                                    "System prompt appears to hand-roll injection "
                                    "defenses in-band; prefer structured messages.",
                                    column=arg.col_offset + 1,
                                    severity=Severity.LOW,
                                )
                            )
        return findings
