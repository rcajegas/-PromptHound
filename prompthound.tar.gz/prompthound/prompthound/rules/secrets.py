"""Detect hardcoded API keys and credentials for AI providers."""
from __future__ import annotations

import re

from ..finding import Severity
from .base import Rule, ScanContext

# (label, compiled pattern). Patterns are deliberately specific to keep
# false positives low; the generic assignment check below catches the rest.
_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("OpenAI API key", re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}")),
    ("Anthropic API key", re.compile(r"\bsk-ant-[A-Za-z0-9_-]{20,}")),
    ("Hugging Face token", re.compile(r"\bhf_[A-Za-z0-9]{30,}")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_-]{30,}")),
    ("AWS access key id", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("Cohere API key", re.compile(r"\bco-[A-Za-z0-9]{40,}")),
    ("Replicate token", re.compile(r"\br8_[A-Za-z0-9]{30,}")),
]

# Assignment like  API_KEY = "somelongvalue"
_ASSIGN = re.compile(
    r"""(?ix)
    \b(?P<name>[A-Za-z0-9_]*
        (?:api[_-]?key|secret|token|password|passwd|access[_-]?key)
    )\s*[:=]\s*
    (?P<q>['"])(?P<val>[^'"]{12,})(?P=q)
    """
)

# Values that are obviously placeholders, not real secrets.
_PLACEHOLDER = re.compile(
    r"(?i)(your[_-]?|example|placeholder|xxxx|<|\{\{|\$\{|changeme|dummy|redacted|sk-\.\.\.)"
)


class HardcodedSecretsRule(Rule):
    id = "PH101"
    name = "hardcoded-ai-credential"
    severity = Severity.CRITICAL
    description = (
        "Load provider keys from environment variables or a secrets manager, "
        "never commit them to source. Rotate any key that has been committed."
    )
    cwe = "CWE-798"
    references = [
        "https://owasp.org/www-community/vulnerabilities/Use_of_hard-coded_credentials",
    ]

    def scan(self, ctx: ScanContext) -> list[Finding]:  # type: ignore[override]
        findings = []
        for lineno, line in enumerate(ctx.lines, start=1):
            for label, pat in _PATTERNS:
                m = pat.search(line)
                if m and not _PLACEHOLDER.search(m.group(0)):
                    findings.append(
                        self.make_finding(
                            ctx,
                            lineno,
                            f"Possible {label} hardcoded in source.",
                            column=m.start() + 1,
                        )
                    )
            am = _ASSIGN.search(line)
            if am and not _PLACEHOLDER.search(am.group("val")):
                # Skip if it's clearly reading from env, e.g. os.environ[...]
                if "os.environ" in line or "getenv" in line:
                    continue
                findings.append(
                    self.make_finding(
                        ctx,
                        lineno,
                        f"Credential assigned to '{am.group('name')}' looks hardcoded.",
                        column=am.start("val") + 1,
                        severity=Severity.HIGH,
                    )
                )
        return findings
