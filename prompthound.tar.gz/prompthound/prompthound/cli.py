"""PromptHound command-line interface."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .finding import Severity
from .reporters import render
from .rules import all_rules
from .scanner import Scanner

_SEVERITIES = [s.value for s in Severity]

_BANNER = r"""
  ____                            _   _   _                       _
 |  _ \ _ __ ___  _ __ ___  _ __ | |_| | | | ___  _   _ _ __   __| |
 | |_) | '__/ _ \| '_ ` _ \| '_ \| __| |_| |/ _ \| | | | '_ \ / _` |
 |  __/| | | (_) | | | | | | |_) | |_|  _  | (_) | |_| | | | | (_| |
 |_|   |_|  \___/|_| |_| |_| .__/ \__|_| |_|\___/ \__,_|_| |_|\__,_|
                           |_|      sniffing out AI/LLM security flaws
"""


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="prompthound",
        description="Static analyzer for AI/LLM security flaws in source code.",
    )
    p.add_argument("path", nargs="?", default=".",
                   help="File or directory to scan (default: current dir).")
    p.add_argument("-f", "--format", choices=["terminal", "json", "sarif", "markdown"],
                   default="terminal", help="Output format.")
    p.add_argument("-o", "--output", help="Write output to a file instead of stdout.")
    p.add_argument("--min-severity", choices=_SEVERITIES, default="info",
                   help="Only report findings at or above this severity.")
    p.add_argument("--fail-on", choices=_SEVERITIES, default="high",
                   help="Exit non-zero if any finding is at or above this severity "
                        "(use with CI). Default: high.")
    p.add_argument("--no-fail", action="store_true",
                   help="Always exit 0 regardless of findings.")
    p.add_argument("--list-rules", action="store_true",
                   help="List the built-in rules and exit.")
    p.add_argument("--version", action="version",
                   version=f"prompthound {__version__}")
    return p


def _list_rules() -> int:
    for rule in all_rules():
        print(f"{rule.id}  [{rule.severity.value:<8}] {rule.name}")
        print(f"    {rule.description}")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.list_rules:
        return _list_rules()

    target = Path(args.path)
    if not target.exists():
        print(f"error: path not found: {args.path}", file=sys.stderr)
        return 2

    if args.format == "terminal" and not args.output:
        sys.stdout.write(_BANNER + "\n")

    scanner = Scanner(min_severity=Severity(args.min_severity))
    result = scanner.scan_path(str(target))

    rendered = render(result, args.format)
    if rendered is not None:
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
            print(f"wrote {args.format} report to {args.output}", file=sys.stderr)
        else:
            print(rendered)

    if args.no_fail:
        return 0
    fail_threshold = Severity(args.fail_on)
    max_sev = result.max_severity()
    if max_sev is not None and max_sev.rank >= fail_threshold.rank:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
